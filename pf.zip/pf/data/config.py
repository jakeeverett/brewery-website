creds = {
	'user': 'alex',
	'password': 'GoDawgs123!',
	'database': 'craftbrews',
	'auth_plugin': 'mysql_native_password'
}

GOOG_KEY = 'AIzaSyAoQKItAjJkxDgN-uPhll4jtR4nfON7gzs'

